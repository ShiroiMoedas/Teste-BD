package Model;

import java.sql.Date;

public class Produto {
    private String nome;
    private String categoria;
    private Date dataValidade;
    private int quantidadeAtual;
    private int quantidadeMinima;

    public Produto(String nome, String categoria, Date dataValidade, int quantidadeAtual, int quantidadeMinima) {
        this.nome = nome;
        this.categoria = categoria;
        this.dataValidade = dataValidade;
        this.quantidadeAtual = quantidadeAtual;
        this.quantidadeMinima = quantidadeMinima;
    }

    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public Date getDataValidade() { return dataValidade; }
    public int getQuantidadeAtual() { return quantidadeAtual; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
}