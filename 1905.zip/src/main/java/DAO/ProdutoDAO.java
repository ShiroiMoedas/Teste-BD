package DAO;

import Conexao.Conexao;
import Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProdutoDAO {

    public void criarTabela() throws Exception {
        String sql = "CREATE TABLE IF NOT EXISTS produtos (" +
                "id_produto INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT, " +
                "categoria TEXT, " +
                "data_validade TEXT, " +
                "quantidade_atual INTEGER, " +
                "quantidade_minima INTEGER);";
        Connection conn = Conexao.getConnection();

        if (conn == null) {
            System.out.println("Nao foi possivel criar a tabela pois a conexao e nula.");
            return;
        }

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void cadastrar(Produto p) throws Exception {
        String sql = "INSERT INTO produtos (nome, categoria, data_validade, quantidade_atual, quantidade_minima) VALUES (?, ?, ?, ?, ?)";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, p.getNome());
        stmt.setString(2, p.getCategoria());
        stmt.setString(3, p.getDataValidade().toString());
        stmt.setInt(4, p.getQuantidadeAtual());
        stmt.setInt(5, p.getQuantidadeMinima());
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void listarTodos() throws Exception {
        String sql = "SELECT * FROM produtos";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getInt("id_produto") + " | " + rs.getString("nome") + " | Qtd: " + rs.getInt("quantidade_atual"));
        }
        rs.close();
        stmt.close();
        conn.close();
    }

    public void verificarEstoqueAbaixoDoMinimo() throws Exception {
        String sql = "SELECT * FROM produtos WHERE quantidade_atual < quantidade_minima";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            System.out.println("ALERTA: " + rs.getString("nome") + " abaixo do mínimo!");
        }
        rs.close();
        stmt.close();
        conn.close();
    }

    public void listarPorCategoria(String categoria) throws Exception {
        String sql = "SELECT * FROM produtos WHERE categoria = ?";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, categoria);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("nome") + " - " + rs.getString("categoria"));
        }
        rs.close();
        stmt.close();
        conn.close();
    }

    public void listarVencidos() throws Exception {
        String sql = "SELECT * FROM produtos WHERE data_validade < date('now')";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            System.out.println("VENCIDO: " + rs.getString("nome") + " - Data: " + rs.getString("data_validade"));
        }
        rs.close();
        stmt.close();
        conn.close();
    }

    public void listarProximosAoVencimento() throws Exception {
        String sql = "SELECT * FROM produtos WHERE data_validade BETWEEN date('now') AND date('now', '+7 days')";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            System.out.println("VENCE EM BREVE: " + rs.getString("nome") + " - Data: " + rs.getString("data_validade"));
        }
        rs.close();
        stmt.close();
        conn.close();
    }

    public void alterarQuantidadeEstoque(int idProduto, int quantidadeAlteracao) throws Exception {
        String sql = "UPDATE produtos SET quantidade_atual = quantidade_atual + ? WHERE id_produto = ?";
        Connection conn = Conexao.getConnection();

        if (conn == null) return;

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, quantidadeAlteracao);
        stmt.setInt(2, idProduto);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
}