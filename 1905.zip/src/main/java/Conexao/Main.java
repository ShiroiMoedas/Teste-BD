package Conexao;

import DAO.ProdutoDAO;
import Model.Produto;
import java.sql.Date;

public class Main {
    public static void main(String[] args) throws Exception {
        ProdutoDAO dao = new ProdutoDAO();

        dao.criarTabela();

        dao.cadastrar(new Produto("Pão Francês", "Pães", Date.valueOf("2026-05-20"), 50, 30));
        dao.cadastrar(new Produto("Bolo de Chocolate", "Bolos", Date.valueOf("2026-05-22"), 5, 10));
        dao.cadastrar(new Produto("Leite Integral", "Bebidas", Date.valueOf("2026-06-01"), 12, 8));

        System.out.println("--- Todos os produtos ---");
        dao.listarTodos();

        System.out.println("--- Estoque baixo ---");
        dao.verificarEstoqueAbaixoDoMinimo();

        System.out.println("--- Apenas Bolos ---");
        dao.listarPorCategoria("Bolos");

        System.out.println("--- Vencidos ---");
        dao.listarVencidos();

        System.out.println("--- Vencem em 7 dias ---");
        dao.listarProximosAoVencimento();

        System.out.println("--- Modificando Estoque ---");
        dao.alterarQuantidadeEstoque(1, 20);
        dao.alterarQuantidadeEstoque(1, -10);

        System.out.println("--- Lista Atualizada ---");
        dao.listarTodos();
    }
}