package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    public static Connection getConnection() {
        try {
            String url = "jdbc:sqlite:identifier.sqlite";
            Connection conn = DriverManager.getConnection(url);
            System.out.println("Conectado com sucesso.");
            return conn;
        } catch (SQLException e) {
            System.out.println("Conexão Falhou");
            return null;
        }
    }
}